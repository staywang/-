function dlg(){
    var whitebg=document.getElementById("white-background");
    var dlg=document.getElementById("dlgbox");
    whitebg.style.display="none";
    dlg.style.display="none";
}
function showdialog(){
     
    var whitebg=document.getElementById("white-background");
    var dlg=document.getElementById("dlgbox");
    whitebg.style.display="block";
    dlg.style.display="block";

    var winWidth=window.innerWidth;
    var winHeight=window.innerHeight;
    
    dlg.style.left=(winWidth/2)-480/2+"px";
    dlg.style.top="150px";
   
   
  
}

 
  

function sub()
{
  
var r=confirm("please confirm your submit");

if(r==true){ 
  window.open("reportfault.html");
  alert(window.location);
}
else {
  alert("cancel your submit ");
}}
function res()
{
alert("your want to reset your submit?")	
}
