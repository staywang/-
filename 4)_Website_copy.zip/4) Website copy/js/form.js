function sub1()
{
  
var r=confirm("please confirm your submit");

if(r==true){ 
  window.open("reportfault.html");
  alert(window.location);
}
else {
  alert("cancel your submit ");
}}
function res()
{
alert("your want to reset your submit?")	
}









function sub2()
{
  
var r=confirm("please confirm your submit");

if(r==true){ 
  window.open("summary.html");
  alert(window.location);
}
else {
  alert("cancel your submit ");
}}
function res()
{
alert("your want to reset your submit?")	
}

function sub3()
{
  
var r=confirm("please confirm your submit");

if(r==true){ 
  window.open("summaryb.html");
  alert(window.location);
}
else {
  alert("please check again ensure your reference number");
}}
function res()
{
alert("your want to reset your submit?")	
}
function jumptoimage(){

  window.open("image.html");
  alert(window.location);

}
function sub4()
{
  
var r=confirm("please confirm your submit");

if(r==true){ 
  window.open("reportFault.html");
  alert(window.location);
}
else {
  alert("please check again");
}}

function sub5()
{
  
var r=confirm("Thank you very much!");

if(r==true){ 
  window.open("index.html");
  alert(window.location);
}
else {
  alert("please check again");
}}